package com.training.pomdemo.core;
import java.io.InputStream; 

import java.util.Properties; 

 

public class ConfigReader { 

    private static final Properties props = new Properties(); 

 

    static { 

        try (InputStream is = ConfigReader.class.getClassLoader().getResourceAsStream("config.properties")) { 

            if (is == null) { 

                throw new RuntimeException("config.properties not found in src/test/resources"); 

            } 

            props.load(is); 

        } catch (Exception e) { 

            throw new RuntimeException("Failed to load config.properties", e); 

        } 

    } 

 

    public static String get(String key) { 

        String val = props.getProperty(key); 

        if (val == null) { 

            throw new RuntimeException("Missing key in config.properties: " + key); 

        } 

        return val.trim(); 

    } 

} 
