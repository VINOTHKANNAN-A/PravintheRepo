package com.training.pomdemo.core;

import java.time.Duration; 



import org.openqa.selenium.WebDriver; 

import org.openqa.selenium.chrome.ChromeDriver; 

import org.openqa.selenium.edge.EdgeDriver; 

import org.openqa.selenium.firefox.FirefoxDriver; 

 

public class DriverFactory { 

 

    public static WebDriver createDriver(String browser) { 

        WebDriver driver; 

 

        switch (browser.toLowerCase()) { 

            case "edge": 

                driver = new EdgeDriver(); 

                break; 

            case "firefox": 

                driver = new FirefoxDriver(); 

                break; 

            case "chrome": 

            default: 

                driver = new ChromeDriver(); // Selenium Manager auto-handles driver binaries 

                break; 

        } 

 

        driver.manage().window().maximize(); 

        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30)); 

        driver.manage().timeouts().implicitlyWait(Duration.ZERO); // we use explicit waits only 

        return driver; 

    } 

} 

