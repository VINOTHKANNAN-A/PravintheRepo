package com.training.pomdemo.pages;

import java.time.Duration; 



import org.openqa.selenium.By; 

import org.openqa.selenium.WebDriver; 

import org.openqa.selenium.WebElement; 

import org.openqa.selenium.support.ui.ExpectedConditions; 

import org.openqa.selenium.support.ui.WebDriverWait; 

 

public class BasePage { 

 

    protected WebDriver driver; 

    protected WebDriverWait wait; 

 

    public BasePage(WebDriver driver) { 

        this.driver = driver; 

        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 

    } 

 

    protected void type(By locator, String text) { 

        WebElement el = wait.until(ExpectedConditions.visibilityOfElementLocated(locator)); 

        el.clear(); 

        el.sendKeys(text); 

    } 

 

    protected void click(By locator) { 

        wait.until(ExpectedConditions.elementToBeClickable(locator)).click(); 

    } 

 

    protected String getText(By locator) { 

        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).getText(); 

    } 

 

    protected boolean isVisible(By locator) { 

        try { 

            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed(); 

        } catch (Exception e) { 

            return false; 

        } 

    } 

} 