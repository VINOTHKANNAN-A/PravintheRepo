package com.training.pomdemo.base;

import org.openqa.selenium.WebDriver; 

import org.testng.annotations.AfterMethod; 

import org.testng.annotations.BeforeMethod; 

 

import com.training.pomdemo.core.ConfigReader; 

import com.training.pomdemo.core.DriverFactory; 

 

public class BaseTest { 

 

    protected WebDriver driver; 

 

    @BeforeMethod 

    public void setUp() { 

        String browser = ConfigReader.get("browser"); 

        driver = DriverFactory.createDriver(browser); 

    } 

 

    @AfterMethod(alwaysRun = true) 

    public void tearDown() { 

        if (driver != null) driver.quit(); 

    } 

} 