package com.training.pomdemo.tests;
import org.testng.Assert; 

import org.testng.annotations.Test; 

 

import com.training.pomdemo.base.BaseTest; 

import com.training.pomdemo.core.ConfigReader; 

import com.training.pomdemo.pages.LoginPage; 

import com.training.pomdemo.pages.SecureAreaPage; 

 

public class LoginTest extends BaseTest { 

 

    @Test 

    public void validLogin_shouldGoToSecureArea_andLogout() { 

        String url = ConfigReader.get("baseUrl"); 

        String user = ConfigReader.get("username"); 

        String pass = ConfigReader.get("password"); 

 

        LoginPage loginPage = new LoginPage(driver).open(url); 

 

        SecureAreaPage secure = loginPage.loginValid(user, pass); 

 

        Assert.assertTrue(secure.isAt(), "User is NOT on Secure Area page!"); 

        Assert.assertTrue(secure.getMessage().contains("You logged into a secure area!"), 

                "Success message not found!"); 

 

        secure.logout(); 

        Assert.assertTrue(driver.getCurrentUrl().contains("/login"), "Logout failed!"); 

    } 

 

    @Test 

    public void invalidLogin_shouldShowErrorMessage() { 

        String url = ConfigReader.get("baseUrl"); 

 

        LoginPage loginPage = new LoginPage(driver).open(url); 

 

        String msg = loginPage.loginInvalidAndGetMessage("tomsmith", "wrongPassword"); 

 

        Assert.assertTrue(msg.toLowerCase().contains("invalid"), "Invalid message not shown!"); 

    } 

} 


