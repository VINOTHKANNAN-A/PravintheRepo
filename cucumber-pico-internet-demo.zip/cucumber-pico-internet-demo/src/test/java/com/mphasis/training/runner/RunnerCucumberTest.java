package com.mphasis.training.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = "src/test/resources/Features",
		glue = "com.mphasis.training",
		monochrome = true
		)
public class RunnerCucumberTest extends AbstractTestNGCucumberTests{
	// TestNG runner that points to features + glue packages.
	
	
}
