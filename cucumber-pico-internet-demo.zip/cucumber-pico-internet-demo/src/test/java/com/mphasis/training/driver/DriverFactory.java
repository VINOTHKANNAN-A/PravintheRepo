package com.mphasis.training.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DriverFactory {
	//Creates WebDriver in one place
	
	public WebDriver createChromeDriver() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximize");
		return new ChromeDriver(options);
	}
}
