@ui @orangehrm @create
Feature: Create an admin user in OrangeHRM
  As an Admin
  I want to create a new user
  So that I can manage users in the system

  Background:
    Given I am on the OrangeHRM login page "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    And I login with username "Admin" and password "admin123"
    And I navigate to the "Admin" page from the left sidebar

  @smoke @regression
  Scenario: Create an enabled admin user
    When I click on the Add User button
    And I create a user with details:
      | User Role       | ESS       |
      | Employee Name   | a |
      | Username        | test.admin01 |
      | Status          | Enabled     |
      | Password        | Admin@123   |
      | ConfirmPassword | Admin@123   |
    
    