@ui @orangehrm @delete
Feature: Delete an admin user in OrangeHRM
  As an Admin
  I want to search for a user and delete it
  So that I can manage users in the system

  Background:
    Given I am on the OrangeHRM login page "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    And I login with username "Admin" and password "admin123"

  @smoke @regression
  Scenario: Delete the admin user with Enabled status
    When I navigate to the "Admin" page from the left sidebar
    And I search users with:
      | Username | test.admin01  |
      | Role     | ESS  |
      |EmployeeName|a|
      | Status   | Enabled|
    And I click the delete icon for user "test.admin01"
    And I confirm the deletion in the dialog
  

    	