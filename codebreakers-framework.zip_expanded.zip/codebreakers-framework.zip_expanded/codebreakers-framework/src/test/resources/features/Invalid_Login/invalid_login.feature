@ui @orangehrm @login @negative
Feature: Invalid login to OrangeHRM

  As a user
  I want to try logging in with invalid credentials
  So that the application shows a proper error message

  Background:
    Given I am on the OrangeHRM login page "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

  @smoke @regression
  Scenario: Login with invalid username and password
    When I login with invalid username "InvalidUser" and password "InvalidPass123"
    Then I should see a login error message "Invalid credentials"
