package com.training.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/Features",
        glue = "com.training",
        monochrome = true,
        plugin = {"pretty", "html:target/cucumber.html"}
        //tags = "ui and orangehrm and delete and smoke and regression"
)
public class RunnerCucumberTest extends AbstractTestNGCucumberTests {
}