package com.training.steps;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;
import com.training.context.TestContext;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public LoginSteps(TestContext context) {
        this.driver = context.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Given("I am on the OrangeHRM login page {string}")
    public void openLoginPage(String url) {
        driver.get(url);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
    }

    @Given("I login with username {string} and password {string}")
    public void login(String user, String pass) {
        driver.findElement(By.name("username")).sendKeys(user);
        driver.findElement(By.name("password")).sendKeys(pass);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("aside")));
    }
    
    @When("I login with invalid username {string} and password {string}")
    public void loginWithInvalidCredentials(String username, String password) {
    	driver.findElement(By.name("username")).sendKeys(username);
    	driver.findElement(By.name("password")).sendKeys(password);
        WebElement submitBtn = driver.findElement(By.cssSelector("button[type='submit']"));
        wait.until(ExpectedConditions.elementToBeClickable(submitBtn)).click();
    }
    
    @Then("I should see a login error message {string}")
    public void verifyLoginErrorMessage(String expectedMessage) throws IOException, InterruptedException {
        By errorMsg = By.xpath("//p[contains(@class,'oxd-alert-content-text')]");
        WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsg));

        String actualText = message.getText().trim();
        org.testng.Assert.assertTrue(
                actualText.contains(expectedMessage),
                "Expected error message: " + expectedMessage + " but found: " + actualText
        );
        
        takescreenshotss();
        Thread.sleep(2000);
        driver.close(); 
    }
    public void takescreenshotss() throws IOException, InterruptedException {
    	File bytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Files.copy(bytes,new File("C:/Users/vinothkannan.a/eclipse-workspace/codebreakers-framework.zip_expanded/codebreakers-framework/Output/Invalid.png"));
        Thread.sleep(3000);
    }
}
