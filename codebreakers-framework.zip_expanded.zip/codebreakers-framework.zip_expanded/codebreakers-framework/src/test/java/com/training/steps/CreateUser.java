package com.training.steps;

import com.training.context.TestContext;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.Map;



public class CreateUser {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public CreateUser(TestContext context) {
        this.driver = context.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @When("I click on the Add User button")
    public void clickAdd() {
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[.=' Add ']"))).click();
    }

    @When("I create a user with details:")
    public void createUser(DataTable table) throws InterruptedException {
        Map<String, String> data = table.asMap();

        selectDropdown("User Role", data.get("User Role"));
        type("Employee Name", data.get("Employee Name"));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@role='listbox']//span"))).click();
        type("Username", data.get("Username"));
        selectDropdown("Status", data.get("Status"));
        type("Password", data.get("Password"));
        type("Confirm Password", data.get("ConfirmPassword"));

        driver.findElement(By.xpath("//button[.=' Save ']")).click();
        Thread.sleep(4000);
        driver.close();
    }


    private void type(String label, String value) {
        By input = By.xpath("//label[text()='" + label + "']/../following-sibling::div//input");
        WebElement el = wait.until(ExpectedConditions.elementToBeClickable(input));
        el.clear();
        el.sendKeys(value);
    }

    private void selectDropdown(String label, String value) {
        By drop = By.xpath("//label[text()='" + label + "']/../following-sibling::div//div[contains(@class,'select-text')]");
        wait.until(ExpectedConditions.elementToBeClickable(drop)).click();
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//span[text()='" + value + "']")
        )).click();
    }
}
