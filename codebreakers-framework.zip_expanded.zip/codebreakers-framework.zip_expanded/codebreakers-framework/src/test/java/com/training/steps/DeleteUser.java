package com.training.steps;

import com.google.common.io.Files;
import com.training.context.TestContext;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.io.File;
import java.io.IOException;
import java.time.Duration;


public class DeleteUser {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public DeleteUser(TestContext context) throws InterruptedException {
    	
        driver = context.getDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @When("I search users with:")
    public void searchUser(io.cucumber.datatable.DataTable table) throws InterruptedException, IOException {
        String username = table.asMap().get("Username");
        WebElement userInput = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[text()='Username']/../following-sibling::div//input")
        ));
        userInput.clear();
        userInput.sendKeys(username);
        driver.findElement(By.xpath("//button[.=' Search ']")).click();
        scrollToBottom();
        
        Thread.sleep(3000);
        takescreenshotss();
//        Thread.sleep(10000);
//        driver.close();
        
    }
    
    private void scrollToBottom() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }

	public void takescreenshotss() throws IOException, InterruptedException {
    	File bytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Files.copy(bytes,new File("C:/Users/vinothkannan.a/eclipse-workspace/codebreakers-framework.zip_expanded/codebreakers-framework/Output/result.png"));
        Thread.sleep(3000);
    }

    @When("I click the delete icon for user {string}")
    public void deleteUser(String username) {
        By deleteBtn = By.xpath("//div[text()='" + username + "']/ancestor::div[@role='row']//button");
        wait.until(ExpectedConditions.elementToBeClickable(deleteBtn)).click();
    }


@When("I confirm the deletion in the dialog")
    public void confirmDeletion() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[.=' Yes, Delete ']")
        )).click();
        
        Thread.sleep(2000);
    }



}
 


