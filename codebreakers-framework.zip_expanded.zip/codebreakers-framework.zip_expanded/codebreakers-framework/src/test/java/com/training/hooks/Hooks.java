package com.training.hooks;

import com.training.context.TestContext;
import com.training.driver.DriverFactory;
import io.cucumber.java.Before;

public class Hooks {

    private final TestContext testContext;

    public Hooks(TestContext testContext) {
        this.testContext = testContext;
    }

    @Before
    public void setUp() {
        DriverFactory factory = new DriverFactory();
        testContext.setDriver(factory.createChromeDriver());
    }


}