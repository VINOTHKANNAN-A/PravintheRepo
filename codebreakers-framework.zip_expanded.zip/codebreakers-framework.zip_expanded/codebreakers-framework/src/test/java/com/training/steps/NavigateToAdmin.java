package com.training.steps;

import com.training.context.TestContext;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class NavigateToAdmin {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public NavigateToAdmin(TestContext context) {
        this.driver = context.getDriver();
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @When("I navigate to the {string} page from the left sidebar")
    public void navigate(String menu) {
        By adminLink = By.xpath("//span[text()='Admin']");
        wait.until(ExpectedConditions.elementToBeClickable(adminLink)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[text()='Admin']")));
    }
}
