package tests;
import org.testng.annotations.Test;
public class PaymenTest {
	@Test
	public void makepayment() {
		System.out.println("PaymentTest -> PaymentDone");
	}
	@Test
	public void paymentFailure() {
		System.out.println("PaymentTest -> Failure");
	}
	
	@Test
	public void refundPayment() {
		System.out.println("PaymentTest -> Refund");
	}
}
