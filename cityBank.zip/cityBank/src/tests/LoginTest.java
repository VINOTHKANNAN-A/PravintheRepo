package tests;
import org.testng.annotations.Test;
public class LoginTest {
	@Test
	public void validLoginTest() {
		System.out.println("LoginTest -> validLoginTest executed");
	}
	@Test
	public void inValidLoginTest() {
		System.out.println("LoginTest -> inValidLoginTest executed");
	}
}
