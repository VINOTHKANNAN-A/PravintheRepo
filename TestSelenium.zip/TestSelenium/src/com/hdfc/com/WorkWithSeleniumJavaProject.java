package com.hdfc.com;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
 
public class WorkWithSeleniumJavaProject {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.selenium.dev/downloads/");
		
		String pageTitle = driver.getTitle(); // Print the title to console
		System.out.println("Page Title is: "+ pageTitle);
	}
 
}