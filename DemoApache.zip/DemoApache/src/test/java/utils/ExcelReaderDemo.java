package utils;

import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReaderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 try {
	           String filePath = "TestData.xlsx";   // relative path
	           String sheetName = "LoginData";
	           FileInputStream fis = new FileInputStream(filePath);
	           Workbook workbook = WorkbookFactory.create(fis);
	           Sheet sheet = workbook.getSheet(sheetName);
	           // Read Row 1 (because Row 0 is header)
	           Row row = sheet.getRow(1);
	           DataFormatter df = new DataFormatter(); // converts any cell value to String
	           String url = df.formatCellValue(row.getCell(0));
	           String username = df.formatCellValue(row.getCell(1));
	           String password = df.formatCellValue(row.getCell(2));
	           System.out.println("URL : " + url);
	           System.out.println("Username : " + username);
	           System.out.println("Password : " + password);
	           workbook.close();
	           fis.close();
	       } catch (Exception e) {
	           e.printStackTrace();
	       }

	}

}

