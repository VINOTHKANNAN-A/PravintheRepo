package WebDriverCommand;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WorkingWithNavigate {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://google.com");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		System.out.println("Tittle Before Clicking on Link --> : "+ driver.getTitle());
		driver.findElement(By.linkText("Store")).click();
		Thread.sleep(3000);
		System.out.println("Tittle After Clicking on Link --> : "+ driver.getTitle());
		driver.navigate().back();
		Thread.sleep(3000);
		driver.navigate().forward();
	}
}