package WebDriverCommand;

import java.time.Duration;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNgAddCookieFunction {
	
	WebDriver driver;
	WebDriver driver1;
	
	public void addCookie(String name,String value) {
		// TODO Auto-generated method stub
		String currenturl = driver.getCurrentUrl();
		if (currenturl == null || currenturl.startsWith("about:bank")) {
			throw new IllegalStateException("Open a wibesite first using.get(url) before adding cookie");
		}
		Cookie cookie = new Cookie(name,value);
		driver.manage().addCookie(cookie);
		driver.navigate().refresh();
		System.out.println("Cookie Added: "+ name + " = " + value);
		
	}
	
	@BeforeMethod
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
		driver.get("https://the-internet.herokuapp.com");
	}
	
	@Test
	public void testadd() {
		addCookie("vinoth","Kannan");
		Cookie fetched = driver.manage().getCookieNamed("vinoth");
		System.out.println("Fetched Cookie => "+fetched);
		
		Assert.assertNotNull(fetched,"Cookie was not found");
		Assert.assertEquals(fetched.getValue(),"Kannan","Cookie value mismatch");
	}
	
	@AfterMethod
	public void teardown() {
		if(driver != null) {
			driver.quit();
		}
	}
	

}
