package WebDriverCommand;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.Set;

public class HandlingCookie {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hdfc.bank.in/");
        Cookie myCookie = new Cookie("Vinoth", "Kannan");
        driver.manage().addCookie(myCookie);
        Set<Cookie> allCookies = driver.manage().getCookies();
        System.out.println("Total Cookies After Add => " + allCookies.size());
        driver.manage().deleteCookieNamed("Vinoth");
        Set<Cookie> allCook = driver.manage().getCookies();
        System.out.println("Total Cookies After cus del => " + allCook.size());
        driver.manage().deleteAllCookies();
        Set<Cookie> afterDelete = driver.manage().getCookies();
        System.out.println("Total Cookies After Add => " + afterDelete.size());
        
        

     //   driver.quit();
    }
}
