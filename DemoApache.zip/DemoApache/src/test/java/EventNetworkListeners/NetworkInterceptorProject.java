package EventNetworkListeners;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.NetworkInterceptor;
import org.openqa.selenium.remote.http.Filter;
import org.openqa.selenium.remote.http.HttpResponse;
 
public class NetworkInterceptorProject {
  public static void main(String[] args) {
    WebDriver driver = new ChromeDriver();
 
    List<String> contentTypes = new CopyOnWriteArrayList<>();
 
    try (NetworkInterceptor ignored =
             new NetworkInterceptor(driver, (Filter) next -> req -> {
               HttpResponse res = next.execute(req); // let the request go to real server
               contentTypes.add(res.getHeader("Content-Type")); // record response header
               return res;
             })) {
 
      driver.get("https://www.selenium.dev/selenium/web/blank.html");
    }
 
    System.out.println("Captured Content-Types:");
    contentTypes.stream().filter(s -> s != null).distinct().forEach(System.out::println);
 
    driver.quit();
  }
}