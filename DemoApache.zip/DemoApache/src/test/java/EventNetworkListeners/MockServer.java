
package EventNetworkListeners;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.NetworkInterceptor;
import org.openqa.selenium.remote.http.Contents;
import org.openqa.selenium.remote.http.HttpResponse;
import org.openqa.selenium.remote.http.Route;

public class MockServer {
  public static void main(String[] args) {
    ChromeDriver driver = new ChromeDriver();

    String targetUrl = "https://jsonplaceholder.typicode.com/todos/1";

String mockJson =
    "{\n" +
    "  \"userId\": 99,\n" +
    "  \"id\": 1,\n" +
    "  \"title\": \"MOCKED BY SELENIUM\",\n" +
    "  \"completed\": true\n" +
    "}";


    try (NetworkInterceptor ignored =
        new NetworkInterceptor(
            driver,
            // IMPORTANT: getUri() is typically just the path/query, not the full origin
            Route.matching(req -> req.getUri().contains("/todos/1"))
                 .to(() -> req -> new HttpResponse()
                     .setStatus(200)
                     .addHeader("Content-Type", "application/json; charset=utf-8")
                     .setContent(Contents.utf8String(mockJson)))
        )) {

      driver.get(targetUrl);

      // JSON pages render inside <pre> in Chromium
      String bodyText = driver.findElement(By.tagName("pre")).getText();
      System.out.println("Body text: " + bodyText);
      System.out.println("Page contains mocked title? " + bodyText.contains("MOCKED BY SELENIUM"));
    } finally {
      driver.quit();
    }
  }
}
