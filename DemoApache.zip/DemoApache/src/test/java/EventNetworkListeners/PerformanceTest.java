package EventNetworkListeners;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;

public class PerformanceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver driver = new ChromeDriver();
		 
	    long start = System.currentTimeMillis();
	    driver.get("https://amazon.com");
	    long end = System.currentTimeMillis();
	 
	    System.out.println("Simple page load time (ms) = " + (end - start));
	 
	    // More accurate (Navigation Timing)
	    Object loadMs = ((JavascriptExecutor) driver).executeScript(
	        "const nav = performance.getEntriesByType('navigation')[0];" +
	        "return nav ? Math.round(nav.loadEventEnd - nav.startTime) : -1;"
	    );
	    System.out.println(loadMs);
	}

}

    