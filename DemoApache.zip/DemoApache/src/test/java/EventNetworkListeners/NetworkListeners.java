package EventNetworkListeners;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v142.network.Network;
import org.openqa.selenium.devtools.v142.network.model.Request;
import org.openqa.selenium.devtools.v142.network.model.Response;
 
import java.util.Optional;
 
public class NetworkListeners {
  public static void main(String[] args) {
	  ChromeDriver driver = new ChromeDriver();
	  
	    DevTools devTools = driver.getDevTools();
	    devTools.createSession();
	    DevTools MydevTools = ((HasDevTools) driver).getDevTools();
	    System.out.println("Session ID: "+MydevTools.getCdpSession());
	    System.out.println("Session ID: "+driver.getSessionId());
	    // Start capturing network traffic
	    devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty(), java.util.Optional.empty(), java.util.Optional.empty()));
	 
	    // 1) Request events
	    devTools.addListener(Network.requestWillBeSent(), event -> {
	      Request req = event.getRequest();
	      System.out.println(">> REQUEST: " + req.getMethod() + " " + req.getUrl());
	    });
	 
	    // 2) Response events
	    devTools.addListener(Network.responseReceived(), event -> {
	      Response res = event.getResponse();
	      System.out.println("<< RESPONSE: " + (int)res.getStatus() + " " + res.getUrl());
	    });
	 
	    // 3) Failed network events
	    devTools.addListener(Network.loadingFailed(), event -> {
	      System.out.println("!! FAILED: " + event.getErrorText() + " | requestId=" + event.getRequestId());
	    });
	 
	    driver.get("https://google.com");
	 
	    driver.quit();
  }
}