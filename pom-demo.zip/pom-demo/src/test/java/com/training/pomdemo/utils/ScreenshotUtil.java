package com.training.pomdemo.utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ScreenshotUtil {
	public static String takeScreenshot(WebDriver driver, String testName) {
		try {
			Path folder = Paths.get(System.getProperty("user.dir"), "screenshots");
			Files.createDirectories(folder);
			String fileName = testName + "_" + System.currentTimeMillis() + ".png";
			Path dest = folder.resolve(fileName);
			byte[] bytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			Files.write(dest, bytes);
			return dest.toAbsolutePath().toString();
		} catch (Exception e) {
			return "Screenshot failed: " + e.getMessage();
		}
	}
}