package com.training.pomdemo.listeners;

import com.training.pomdemo.base.BaseTest;
import com.training.pomdemo.utils.ScreenshotUtil;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
	private static final Logger log = LoggerFactory.getLogger(TestListener.class);

	@Override
	public void onTestFailure(ITestResult result) {
		String testName = result.getName();
		log.error("TEST FAILED: {}", testName, result.getThrowable());
		Object instance = result.getInstance();
		if (instance instanceof BaseTest) {
			WebDriver driver = ((BaseTest) instance).getDriver();
			if (driver != null) {
//				String path = ScreenshotUtil.takeScreenshot(driver, testName);
//				log.error("Screenshot saved at: {}", path);
			} else {
				log.error("Driver was null, screenshot not taken.");
			}
		} else {
			log.error("Test class is not extending BaseTest, cannot access driver.");
		}
	}
}