package com.training.pomdemo.base;
 
import com.training.pomdemo.core.ConfigReader;
import com.training.pomdemo.core.DriverFactory;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.*;
import java.nio.file.Files;
import java.nio.file.Paths;
 
public class BaseTest {
 
    protected WebDriver driver;
    private static final Logger log = LoggerFactory.getLogger(BaseTest.class);
 
    // ✅ Added: needed so Listener can access driver safely
    public WebDriver getDriver() {
        return driver;
    }
 
    // ✅ Added: create folders so no "path not found" issues
    @BeforeSuite
    public void createFolders() throws Exception {
        Files.createDirectories(Paths.get(System.getProperty("user.dir"), "logs"));
        Files.createDirectories(Paths.get(System.getProperty("user.dir"), "screenshots"));
    }
 
    @BeforeMethod
    public void setUp() {
        String browser = ConfigReader.get("browser");
        log.info("Launching browser: {}", browser);
        driver = DriverFactory.createDriver(browser);
    }
 
    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        log.info("Closing browser");
        if (driver != null) {
            driver.quit();
        }
    }
}
 