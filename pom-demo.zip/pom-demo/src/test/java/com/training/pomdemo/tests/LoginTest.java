package com.training.pomdemo.tests;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.training.pomdemo.base.BaseTest;
import com.training.pomdemo.core.ConfigReader;
import com.training.pomdemo.pages.LoginPage;
import com.training.pomdemo.pages.SecureAreaPage;
import com.training.pomdemo.tests.data.LoginDataProvider;
import com.training.pomdemo.utils.ScreenshotUtil;
 
public class LoginTest extends BaseTest {
 
    private static final Logger log = LoggerFactory.getLogger(LoginTest.class);
 
    @Test(dataProvider = "loginData", dataProviderClass = LoginDataProvider.class)
    public void login_using_excel(String tc, String username, String password, String expected) {
        String url = ConfigReader.get("baseUrl");
        log.info("Opening login page at URL: {}", url);
 
        LoginPage loginPage = new LoginPage(driver).open(url);
 
        if (expected.equalsIgnoreCase("PASS")) {
            log.info("Doing valid login for TC={} with username={}", tc, username);
 
            // Valid login flow
            SecureAreaPage secure = loginPage.loginValid(username, password);
 
            log.info("Verifying secure area page for TC={}", tc);
            Assert.assertTrue(secure.isAt(),
                    "TC=" + tc + " | Expected Secure Area page, but not landed.");
 
            log.info("Verifying secure area success message for TC={}", tc);
            Assert.assertTrue(secure.getMessage().contains("You logged into a secure area!"),
                    "TC=" + tc + " | Expected success message not found!");
 
            secure.logout();
            log.info("Logged out for TC={}", tc);
 
            Assert.assertTrue(driver.getCurrentUrl().contains("/login"),
                    "TC=" + tc + " | Logout failed!");
        } else {
            log.info("Doing invalid login for TC={} with username={}", tc, username);
 
            // Invalid login flow
            String msg = loginPage.loginInvalidAndGetMessage(username, password);
 
            log.info("Verifying invalid login message for TC={}", tc);
            Assert.assertTrue(msg.toLowerCase().contains("invalid"),
                    "TC=" + tc + " | Expected invalid login message not found!");
        }
    }
    
    @AfterMethod(alwaysRun = true)
	public void onFailureCaptureEvidence(ITestResult result) {
		if(!result.isSuccess()) {
			log.error("TEST FAILED: {}",result.getName());
			String scrPath = ScreenshotUtil.takeScreenshot(driver, result.getName());
			log.error("Screenshot saved at: {}", scrPath);
		}
	}
}