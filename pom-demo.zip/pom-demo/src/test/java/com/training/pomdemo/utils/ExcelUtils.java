package com.training.pomdemo.utils;

import org.apache.poi.ss.usermodel.*;
import java.io.InputStream;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class ExcelUtils {
	// Reads Excel sheet data and returns Object[][]
    // Assumes: Row 0 = header, data starts from Row 1
    public static Object[][] readSheetAs2DArray(String excelPath, String sheetName) {
        Path path = Paths.get(excelPath);
 
        if (!Files.exists(path)) {
            throw new RuntimeException("Excel file NOT found at: " + path.toAbsolutePath());
        }
 
        try (InputStream is = Files.newInputStream(path);
             Workbook wb = WorkbookFactory.create(is)) {
 
            Sheet sheet = wb.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Sheet not found: '" + sheetName + "'. Please check the sheet name in Excel.");
            }
 
            DataFormatter formatter = new DataFormatter();
            Row header = sheet.getRow(0);
            if (header == null) {
                throw new RuntimeException("Header row is missing in sheet: " + sheetName);
            }
 
            int colCount = header.getLastCellNum();   // number of columns
            int lastRow = sheet.getLastRowNum();      // last row index
 
            if (lastRow < 1) {
                throw new RuntimeException("No data rows found. Add rows after header in sheet: " + sheetName);
            }
 
            List<Object[]> rows = new ArrayList<>();
 
            for (int r = 1; r <= lastRow; r++) { // start from row 1 (skip header)
                Row row = sheet.getRow(r);
                if (row == null) continue;
 
                Object[] data = new Object[colCount];
                boolean hasAnyValue = false;
 
                for (int c = 0; c < colCount; c++) {
                    Cell cell = row.getCell(c, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    String value = formatter.formatCellValue(cell).trim();
                    data[c] = value;
                    if (!value.isEmpty()) hasAnyValue = true;
                }
 
                // skip fully blank rows
                if (hasAnyValue) rows.add(data);
            }
 
            return rows.toArray(new Object[0][0]);
 
        } catch (Exception e) {
            throw new RuntimeException("Failed to read Excel: " + path.toAbsolutePath(), e);
        }
    }
}
