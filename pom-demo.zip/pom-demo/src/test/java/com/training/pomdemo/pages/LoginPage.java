package com.training.pomdemo.pages; 

 

import org.openqa.selenium.By; 

import org.openqa.selenium.WebDriver; 

 

public class LoginPage extends BasePage { 

 

    // Locators on https://the-internet.herokuapp.com/login 

    private final By username = By.id("username"); 

    private final By password = By.id("password"); 

    private final By loginBtn = By.cssSelector("button[type='submit']"); 

    private final By flashMsg = By.id("flash"); 

 

    public LoginPage(WebDriver driver) { 

        super(driver); 

    } 

 

    public LoginPage open(String url) { 

        driver.get(url); 

        return this; 

    } 

 

    public SecureAreaPage loginValid(String user, String pass) { 

        type(username, user); 

        type(password, pass); 

        click(loginBtn); 

        return new SecureAreaPage(driver); 

    } 

 

    // For negative test (wrong creds) 

    public String loginInvalidAndGetMessage(String user, String pass) { 

        type(username, user); 

        type(password, pass); 

        click(loginBtn); 

        return getText(flashMsg); 

    } 

}