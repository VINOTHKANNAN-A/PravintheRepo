package com.training.pomdemo.tests.data; 
import org.testng.annotations.DataProvider; 
import com.training.pomdemo.utils.ExcelUtils; 
import java.nio.file.Paths; 
public class LoginDataProvider { 
	@DataProvider(name = "loginData") 
	public static Object[][] loginData() { 
		String excelPath = Paths.get(System.getProperty("user.dir"), "testdata", "LoginData.xlsx").toAbsolutePath().toString(); 
		return ExcelUtils.readSheetAs2DArray(excelPath, "LoginData"); 
	} 
}