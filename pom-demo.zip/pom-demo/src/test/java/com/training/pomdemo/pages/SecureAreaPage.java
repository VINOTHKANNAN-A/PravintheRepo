package com.training.pomdemo.pages; 

 

import org.openqa.selenium.By; 

import org.openqa.selenium.WebDriver; 

 

public class SecureAreaPage extends BasePage { 

 

    private final By heading = By.cssSelector("div.example h2"); 

    private final By flashMsg = By.id("flash"); 

    private final By logoutBtn = By.cssSelector("a.button.secondary.radius"); 

 

    public SecureAreaPage(WebDriver driver) { 

        super(driver); 

    } 

 

    public boolean isAt() { 

        return isVisible(heading) && getText(heading).contains("Secure Area"); 

    } 

 

    public String getMessage() { 

        return getText(flashMsg); 

    } 

 

    public void logout() { 

        click(logoutBtn); 

    } 

}