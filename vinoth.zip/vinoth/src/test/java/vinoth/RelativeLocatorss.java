//package vinoth;
//
//import java.time.Duration;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.locators.RelativeLocator;
//
//public class RelativeLocator {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//        driver.manage().window().maximize();
//        
//        driver.get("https://suacedemo.com");
//        WebElement password = driver.findElement(By.id("password"));
//        WebElement username = driver.findElement(RelativeLocator.with(By.tagName("input")).above(password));
//
//        username.sendKeys("standard_user");
//        password.sendKeys("secret_sauce");
//        driver.findElement(By.id("login-button")).click();
//
//	}
//
//}

package vinoth;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
 
public class RelativeLocatorss {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.saucedemo.com/");
 
        // Locate the password field directly
        WebElement password = driver.findElement(By.id("password"));
 
        // Find the username field ABOVE the password field
        WebElement username = driver.findElement(
            RelativeLocator.with(By.tagName("input")).above(password)
        );
 
        // Find the login button BELOW the password field
        WebElement loginButton = driver.findElement(
            RelativeLocator.with(By.tagName("input")).below(password)
        );
 
        // Interact with the elements
        username.sendKeys("standard_user");
        password.sendKeys("secret_sauce");
        loginButton.click();
 
    }

}
 