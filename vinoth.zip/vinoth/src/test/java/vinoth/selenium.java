package vinoth;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class selenium {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.get("https://www.selenium.dev");
		driver.navigate().to("https://www.selenium.dev");
		System.out.println(""+driver.navigate());
		Thread.sleep(2000);
		System.out.println("The titele of the page is: "+driver.getTitle());
		System.out.println("The Web URL is: "+driver.getCurrentUrl());
		System.out.println("The Source of the page is: "+driver.getPageSource());
		
		//driver.quit();
		
	}

}
