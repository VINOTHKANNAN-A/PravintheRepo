package vinoth;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MyRightClick {
	public static void main(String[] args) throws InterruptedException  {
		WebDriver driver = new ChromeDriver();
        driver.get("https://the-internet.herokuapp.com/context_menu");
        Thread.sleep(1000);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        WebElement webBox = driver.findElement(By.id("hot-spot"));
        Actions act = new Actions(driver);
        act.contextClick(webBox).perform();
        Alert alert = driver.switchTo().alert();   
        System.out.println("Right click accepted"+" "+ alert.getText());
        
	}
}
