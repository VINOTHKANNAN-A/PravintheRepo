package vinoth;

import java.time.Duration;
//import java.util.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutorDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        
        driver.get("https://the-internet.herokuapp.com/");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String title = (String) js.executeScript("return document.title");
        String url = (String) js.executeScript("return document.URL");
        System.out.println("Title using js: "+ title);  
        System.out.println("URL using js : "+url);
        
        js.executeScript("window.scrollBy(0,700)");
        Thread.sleep(1500);
        
        WebElement inputlink = driver.findElement(By.linkText("Inputs"));
        js.executeScript("arguments[0].scrollIntoView(true);",inputlink);
        Thread.sleep(1500);
        
        js.executeScript("arguments[0].style.border='3px solid red'",inputlink);
        Thread.sleep(1500);
        
        js.executeScript("arguments[0].click();", inputlink);
        Thread.sleep(1500);
        
        WebElement inputbox = driver.findElement(By.tagName("input"));
        
        js.executeScript("arguments[0].value='abc234';", inputbox);
        Thread.sleep(1500);
        
        for(int i=0;i<3;i++) {
        	 js.executeScript("arguments[0].style.border='3px solid yellow'",inputbox);
             Thread.sleep(1500);
             js.executeScript("arguments[0].style.border='3px solid white'",inputbox);
             Thread.sleep(1500);
             js.executeScript("arguments[0].style.border='3px solid green'",inputbox);
             Thread.sleep(1500);
        }
        	
	}

}
