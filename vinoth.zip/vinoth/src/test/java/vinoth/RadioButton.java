package vinoth;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RadioButton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://practice.expandtesting.com/dropdown");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("select"))); 
		List<WebElement> totalDropDown = driver.findElements(By.tagName("select")); 
		List<WebElement> option = driver.findElements(By.tagName("option"));
		WebElement CountryDrop = driver.findElement(By.id("country"));
		List<WebElement> Countryoption = CountryDrop.findElements(By.tagName("option"));
		System.out.println("Total number of dropdown option : " + option.size());
		System.out.println("Total number of dropdown : " + totalDropDown.size());
		System.out.println("Total number of dropdown : " + Countryoption.size());
		
		//*[@id="elementsPerPageSelect"]/option[3]
	}

}
