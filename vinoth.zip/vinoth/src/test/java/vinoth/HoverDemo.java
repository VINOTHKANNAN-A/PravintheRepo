package vinoth;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HoverDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://the-internet.herokuapp.com/hovers");
        
        Actions actions = new Actions(driver);
        hover(driver,actions);

	}
	public static void hover(WebDriver driver,Actions actions) {
		WebElement img = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/img"));
		WebElement ano = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[1]/div/h5"));
		actions.moveToElement(img).perform();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		WebElement profile = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("View profile")));
		if (profile.isDisplayed()) { 
			System.out.println(ano.getText());
			System.out.println("viewed"); 
		}
	}

}
