package vinoth;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class AppScreenshot {

    public static void main(String[] args) throws IOException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        try {
            driver.get("https://google.com");

            // 1) Wait for page load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            wait.until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState")
                    .equals("complete"));

            // 2) Wait until something is visible on the page (not blank)
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("body")));

            // Optional: small buffer for heavy pages (SPAs)
            Thread.sleep(1000);

            System.out.println("URL: " + driver.getCurrentUrl());
            System.out.println("Title: " + driver.getTitle());

            takeScreenshot(driver, "HomePage_" + System.currentTimeMillis());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            driver.quit();
        }
    }

    static void takeScreenshot(WebDriver driver, String fileName) throws IOException {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        File folder = new File("screenshots");
        if (!folder.exists()) folder.mkdirs();

        File dest = new File(folder, fileName + ".png");
        FileHandler.copy(src, dest);

        System.out.println("Saved screenshot: " + dest.getAbsolutePath());
    }
}
