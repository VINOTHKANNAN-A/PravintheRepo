package vinoth;

//import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.WebDriverWait;

public class LearnActions {

    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://demoqa.com/droppable");
       // WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        Actions actions = new Actions(driver);
        dragdrop(driver, actions);
    }
        
        public static void dragdrop(WebDriver driver, Actions actions) { 
        	WebElement source = driver.findElement(By.id("draggable")); 
        	WebElement target = driver.findElement(By.id("droppable")); 
        	actions.dragAndDrop(source, target).perform();
        	} 
        
}
        
        //driver.switchTo().frame(0);
        
//        WebElement element = driver.findElement(By.tagName("div"));
//        WebElement Source = driver.findElement(By.xpath("//div[@id='draggable']"));
//        WebElement target = driver.findElement(By.id("droppable"));
//        actions.dragAndDrop(Source, target).perform();
//        
//        actions.moveToElement(rightClickBtn).perform();
//        actions.contextClick(rightClickBtn).perform();
//        //WebElement doubleClickBtn = driver.findElement(By.xpath("//button[text()='Double-Click Me To See Alert']"));
//        actions.doubleClick(rightClickBtn).perform();

        // Close browser
        //driver.quit();
    
