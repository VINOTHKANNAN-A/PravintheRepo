package vinoth;


import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class WorkingWithButton {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://edition.cnn.com/");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("a")));
		List<WebElement> links = driver.findElements(By.tagName("a")); 
		System.out.println("Total number of links: " + links.size());
		for (WebElement link : links) { 
			
			String linkText = link.getText().trim(); 
			String linkHref = link.getAttribute("href"); 
			System.out.println(linkText + " -> " + linkHref); 
		}
		
//		WebElement Username = driver.findElement(By.id("username"));
//		Username.sendKeys("tomsmith");
//		WebElement Password = driver.findElement(By.id("password"));
//		Password.sendKeys("SuperSecretPassword!");
//		WebElement LoginButton = driver.findElement(By.className("radius"));
//		LoginButton.click();
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		WebElement succ = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("flash")));
//		System.out.println(succ.getText());
//		WebElement logoutBtn = driver.findElement(By.cssSelector("a.button.secondary.radius"));
//		logoutBtn.click();
//		System.out.println(driver.findElement(By.className("example")).getText());

		
		
		
	}

}
