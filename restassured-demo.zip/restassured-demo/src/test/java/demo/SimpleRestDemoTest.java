package demo;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
 
public class SimpleRestDemoTest {
 
    private static final String BASE_URL = "https://jsonplaceholder.typicode.com";
 
    @BeforeClass
    public void setup() {
        RestAssured.useRelaxedHTTPSValidation();
    }
 
    @Test
    public void demo_GET() {
        System.out.println("===== GET Demo =====");
 
        Response response = RestAssured.get(BASE_URL + "/posts/1");
 
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(response.jsonPath().getInt("id"), 1);
    }
 
    @Test
    public void demo_POST() {
        System.out.println("===== POST Demo =====");
 
        String requestBody = """
                {
                  "title": "REST Assured Demo",
                  "body": "Hello Freshers! This is POST request",
                  "userId": 101
                }
                """;
 
        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .post(BASE_URL + "/posts");
 
        Assert.assertEquals(response.getStatusCode(), 201);
    }
 
    @Test
    public void demo_PUT() {
        System.out.println("===== PUT Demo =====");
 
        String requestBody = """
                {
                  "id": 1,
                  "title": "Updated Title",
                  "body": "Updated body text",
                  "userId": 101
                }
                """;
 
        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .put(BASE_URL + "/posts/1");
 
        Assert .assertEquals(response.getStatusCode(), 200);
    }
    
    @Test
    public void demo_DELETE() {
    	System.out.println("===== DELETE Demo =====");
    	
    	Response response = RestAssured.delete(BASE_URL+"/posts/1");
    	
    	System.out.println("Status Code: " + response.getStatusCode());
        System.out.println("Response JSON:\n" + response.asPrettyString());
        
        Assert.assertEquals(response.getStatusCode(), 200);
    	
    	
    }
}
