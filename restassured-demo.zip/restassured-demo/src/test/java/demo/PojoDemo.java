package demo;
public class PojoDemo {
   // POJO class (Plain Old Java Object) - only data + getters/setters
   static class Student {
       private String name;
       private int age;
       private String cityName;
       // Getter - read value
       public String getName() {
           return name;
       }
       // Setter - set value
       public void setName(String name) {
           this.name = name;
       }
       public int getAge() {
           return age;
       }
       public String getcityname() {
           return cityName;
       }
       public void setcityname(String cityName) {
           this.cityName=cityName;
       }
       public void setAge(int age) {
           this.age = age;
       }
   }
   public static void main(String[] args) {
       // 1) Create object of POJO
       Student s = new Student();
       // 2) Set values into POJO (using setters)
       s.setName("VInoth Kannan");
       s.setAge(21);
       s.setcityname("Bangalore");
       // 3) Read values from POJO (using getters)
       System.out.println("Student Name : " + s.getName());
       System.out.println("Student Age : " + s.getAge());
       System.out.println("Student City Name : " + s.getcityname());
 
       
       // 4) Update value again using setter
       s.setAge(22);
       // 5) Print updated value
       System.out.println("Updated Age : " + s.getAge());
   }
}