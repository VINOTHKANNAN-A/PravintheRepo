package com.training.bdd.steps;

import com.training.bdd.base.DriverFactory;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.testng.Assert;
import java.util.List;
import java.util.Map;
 
public class InternetSteps {
 
    private static final String BASE_URL = "https://the-internet.herokuapp.com";
 
    private WebDriver driver() {
        return DriverFactory.getDriver();
    }
 
    // ---------------- Background Step ----------------
    @Given("I open the base site")
    public void i_open_the_base_site() {
        driver().get(BASE_URL);
    }
 
    // ---------------- Capturing Arguments ----------------
    // Example: I open the page "/login"
    @When("I open the page {string}")
    public void i_open_the_page(String path) {
        driver().get(BASE_URL + path);
    }
 
    // ---------------- DataTable Demo (Key-Value) ----------------
    @When("I login with data table:")
    public void i_login_with_data_table(DataTable table) {
        // Convert DataTable to Map:
        // username -> tomsmith
        // password -> SuperSecretPassword!
        Map<String, String> data = table.asMap(String.class, String.class);
 
        driver().findElement(By.id("username")).sendKeys(data.get("username"));
        driver().findElement(By.id("password")).sendKeys(data.get("password"));
        driver().findElement(By.cssSelector("button[type='submit']")).click();
    }
 
    // ---------------- Doc String Demo ----------------
    @When("I login with doc string:")
    public void i_login_with_doc_string(String docString) {
        // docString contains:
        // username=tomsmith
        // password=SuperSecretPassword!
 
        String username = null;
        String password = null;
 
        for (String line : docString.split("\\R")) { // split by new line
            line = line.trim();
            if (line.startsWith("username=")) username = line.split("=", 2)[1].trim();
            if (line.startsWith("password=")) password = line.split("=", 2)[1].trim();
        }
 
        driver().findElement(By.id("username")).sendKeys(username);
        driver().findElement(By.id("password")).sendKeys(password);
        driver().findElement(By.cssSelector("button[type='submit']")).click();
    }
 
    // ---------------- Assertion ----------------
    @Then("I should see a message containing {string}")
    public void i_should_see_a_message_containing(String expectedText) {
        String msg = driver().findElement(By.cssSelector("#flash")).getText();
        Assert.assertTrue(msg.contains(expectedText), "Actual message was: " + msg);
    }
 
    // ---------------- DataTable Demo (Multiple rows) ----------------
    @When("I select checkboxes:")
    public void i_select_checkboxes(DataTable table) {
        // table:
        // | index |
        // | 1     |
        // | 2     |
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
 
        List<WebElement> boxes = driver().findElements(By.cssSelector("#checkboxes input[type='checkbox']"));
 
        for (Map<String, String> row : rows) {
            int index = Integer.parseInt(row.get("index")); // 1-based index
            WebElement box = boxes.get(index - 1);
 
            if (!box.isSelected()) {
                box.click();
            }
        }
    }
 
    @Then("checkbox {int} should be selected")
    public void checkbox_should_be_selected(int index) {
        List<WebElement> boxes = driver().findElements(By.cssSelector("#checkboxes input[type='checkbox']"));
        Assert.assertTrue(boxes.get(index - 1).isSelected(), "Checkbox " + index + " is NOT selected");
    }
}