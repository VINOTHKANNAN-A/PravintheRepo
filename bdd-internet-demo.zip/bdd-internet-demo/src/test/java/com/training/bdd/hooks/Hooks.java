package com.training.bdd.hooks;

import com.training.bdd.base.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
	
	@Before
	public void beforeScenario(Scenario scenario) {
	    System.out.println("\n=======================================");
	    System.out.println("START: " + scenario.getName());
	    System.out.println("=======================================");
	    DriverFactory.initDriver();
	}

	@After
	public void afterScenario(Scenario scenario) {
	    System.out.println("END: " + scenario.getName());
	    System.out.println("STATUS:" + scenario.getStatus());
	    System.out.println("=======================================\n");
	    DriverFactory.quitDriver();
	}
	 
}
