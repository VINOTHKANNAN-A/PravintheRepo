package com.training.bdd.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
       features = "classpath:features",
       glue = { "com.training.bdd.steps", "com.training.bdd.hooks" },
       plugin = {"pretty"},
       monochrome = true
)
public class RunCucumberTest extends AbstractTestNGCucumberTests {
}