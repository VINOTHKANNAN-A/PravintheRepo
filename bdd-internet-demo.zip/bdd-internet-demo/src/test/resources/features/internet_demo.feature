Feature: The Internet site demo using Background, DataTables and DocStrings
	Background:
		Given I open the base site
	Scenario: Login using DataTable
		 When I open the page "/login"
		 And I login with data table:
		   | username | tomsmith               |
		   | password | SuperSecretPassword!   |
		Then I should see a message containing "You logged into a secure area!"
	Scenario: Login using Doc String
		 When I open the page "/login"
		 And I login with doc string:
			"""
			username=tomsmith
			password=SuperSecretPassword!
			"""
		Then I should see a message containing "You logged into a secure area!"
	Scenario: Select checkboxes using DataTable
 		When I open the page "/checkboxes"
 		And I select checkboxes:
			| index | 
			| 1     |
			| 2     |
		Then checkbox 1 should be selected
		And checkbox 2 should be selected