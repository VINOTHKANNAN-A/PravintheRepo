package Base;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

public class BaseTest {
	   protected WebDriver driver;
	   @BeforeSuite
	   public void createFolders() throws Exception {
	       // Creates logs and screenshots folders before any test runs
	       Files.createDirectories(Paths.get(System.getProperty("user.dir"), "logs"));
	       Files.createDirectories(Paths.get(System.getProperty("user.dir"), "screenshots"));
	   }
	   @BeforeMethod
	   public void setup() {
	       driver = new ChromeDriver();
	       driver.manage().window().maximize();
	   }
	   @AfterMethod(alwaysRun = true)
	   public void tearDown() {
	       if (driver != null) {
	           driver.quit();
	       }
	   }
	
}