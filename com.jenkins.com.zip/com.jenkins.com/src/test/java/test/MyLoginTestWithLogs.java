package test;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import Base.BaseTest;
import utils.ScreenshotUtils;
//import jdk.internal.org.jline.utils.log;
public class MyLoginTestWithLogs extends BaseTest{
	private static final Logger log = LoggerFactory.getLogger(MyLoginTestWithLogs.class);
			
			@Test
			public void Validlogin_shouldPass() {
			log.info("Step 1: Opening login Page");
			driver.get("https://the-internet.herokuapp.com/login");
			
			log.info("Step 2: Enter Username");
			driver.findElement(By.id("username")).sendKeys("tomsth");
			
			log.info("Step 3: Enter Username");
			driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
			
			log.info("Step 4: Click login Button");
			driver.findElement(By.cssSelector("#login > button > i")).click();
			
			log.info("Step 5: Validate sucess message");
			String msg = driver.findElement(By.id("flash")).getText();
			log.info("Message shown: {}", msg);
			
			Assert.assertTrue(msg.contains("You logged into a secure area!"),"login success mesage not found");
			}
			
			@AfterMethod(alwaysRun = true)
			public void onFailureCaptureEvidence(ITestResult result) {
				if(!result.isSuccess()) {
					log.error("Test Failed: {}",result.getName());
					String screenshotpath = ScreenshotUtils.takescreenshot(driver, result.getName());
					log.error("Screenshot saved at: {}", screenshotpath);
				}
			}
			
}
