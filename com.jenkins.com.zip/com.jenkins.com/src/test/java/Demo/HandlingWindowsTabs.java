package Demo;

import java.time.Duration;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
public class HandlingWindowsTabs {
   WebDriver driver;
   @Test
   public void handleChildWindowOpenedByClick() {
     
       driver = new ChromeDriver();
       driver.manage().window().maximize();
       WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
     
       driver.get("https://the-internet.herokuapp.com/windows");
      
       String parentWindow = driver.getWindowHandle();
       System.out.println("Parent Window ID: " + parentWindow);
     
       Set<String> beforeClickHandles = driver.getWindowHandles();
   
       driver.findElement(By.linkText("Click Here")).click();
  
       Set<String> afterClickHandles = driver.getWindowHandles();
   
       afterClickHandles.removeAll(beforeClickHandles);
       String childWindow = afterClickHandles.iterator().next();
       System.out.println("Child Window ID: " + childWindow);
      
       driver.switchTo().window(childWindow);
    
       String childText = wait.until(
               ExpectedConditions.visibilityOfElementLocated(By.tagName("h3"))
       ).getText();
       System.out.println("Child Window Text: " + childText);
       
        driver.close();
   
       driver.switchTo().window(parentWindow);
       System.out.println("Back to Parent Window Title: " + driver.getTitle());
   }
   @Test
   public void openAndHandleNewTabUsingSelenium4() {
    
       driver = new ChromeDriver();
       driver.manage().window().maximize();
 
       driver.get("https://google.com");
       String parentWindow = driver.getWindowHandle();
      
       driver.switchTo().newWindow(WindowType.TAB);
       driver.get("https://the-internet.herokuapp.com");
       System.out.println("New Tab Title: " + driver.getTitle());
       // 4) Close current tab (the new tab)
       driver.close();
       // 5) Switch back to parent tab
       driver.switchTo().window(parentWindow);
       System.out.println("Back to Parent Tab Title: " + driver.getTitle());
   }
   @Test
   public void openAndHandleNewWindowUsingSelenium4() {
      
       driver = new ChromeDriver();
       driver.manage().window().maximize();
       
       driver.get("https://google.com");
       String parentWindow = driver.getWindowHandle();

       driver.switchTo().newWindow(WindowType.WINDOW);
       driver.get("https://the-internet.herokuapp.com/windows");
       System.out.println("New Window Title: " + driver.getTitle());
    
       driver.close();

       driver.switchTo().window(parentWindow);
       System.out.println("Back to Parent Window Title: " + driver.getTitle());
   }
   
   @AfterMethod 
   public void tearDown() {
	   if(driver != null) {
		   driver.quit();
	   }
   }
}
