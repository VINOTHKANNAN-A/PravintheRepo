package Demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleSearchFunctions {

    //private static boolean clicked;

	public static void main(String[] args) {

        WebDriver driver = new ChromeDriver();


        driver.manage().window().maximize();

        driver.get("https://www.google.com");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        By googleSearchBox = By.name("q");

        wait.until(ExpectedConditions.visibilityOfElementLocated(googleSearchBox)).sendKeys("selenium");


        By allSuggestions = By.cssSelector("ul[role='listbox'] li div[role='option']");
        
        List<WebElement> suggestions = wait.until(
        		ExpectedConditions.visibilityOfAllElementsLocatedBy(allSuggestions));
        
        System.out.println("Total suggestions found: " + suggestions.size());

        for (WebElement s : suggestions) {
        	System.out.println(s.getText());

        }
        
        String expected = "selenium webdriver";
        
       // boolean clicked = false;
        for (WebElement s : suggestions) {
        	if (s.getText().equalsIgnoreCase(expected)) {
        		s.click();
        		//clicked = true;
        		break;
        	}
        }
    }
}









