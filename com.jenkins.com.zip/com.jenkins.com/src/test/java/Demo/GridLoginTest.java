//package Demo;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.remote.RemoteWebDriver;
//import org.testng.annotations.Test;
// 
//import java.net.URL;
//
//public class GridLoginTest {
//	
//	    @Test
//	    public void runOnGrid() throws Exception {
//	        // Grid Hub URL (no /wd/hub in Grid 4)
//	        @SuppressWarnings("deprecation")
//			URL gridUrl = new URL("http://localhost:4444");
//	 
//	        DesiredCapabilities caps = new DesiredCapabilities();
//	        caps.setBrowserName("chrome");
//	 
//	        WebDriver driver = new RemoteWebDriver(gridUrl, caps);
//	 
//	        driver.get("https://www.google.com");
//	        System.out.println("Page title: " + driver.getTitle());
//	 
//	        driver.quit();
//	    }
//}
