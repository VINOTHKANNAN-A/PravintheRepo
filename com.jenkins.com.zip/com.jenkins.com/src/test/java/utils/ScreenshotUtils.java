package utils;


import org.openqa.selenium.io.FileHandler;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenshotUtils {
	public static String takescreenshot(WebDriver driver,String fileName) {
		try {
	           File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	           Path folder = Paths.get(System.getProperty("user.dir"), "screenshots");
	           File dest = folder.resolve(fileName + ".png").toFile();
	           FileHandler.copy(src, dest);
	           return dest.getAbsolutePath();
	       } catch (Exception e) {
	           return "Screenshot failed: " + e.getMessage();
	       }
	   }
	}



